plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.miapp.notasdevoz"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.miapp.notasdevoz"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    // Misma firma en cada compilación: así se puede actualizar sin desinstalar
    signingConfigs {
        create("fija") {
            storeFile = rootProject.file("clave.p12")
            storePassword = "notasdevoz"
            keyAlias = "clave"
            keyPassword = "notasdevoz"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fija")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
