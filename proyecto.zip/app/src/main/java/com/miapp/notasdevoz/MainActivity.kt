package com.miapp.notasdevoz

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var estado: TextView
    private lateinit var boton: Button
    private lateinit var lista: ListView
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var archivos: List<File> = emptyList()

    private val reloj = object : Runnable {
        override fun run() {
            if (RecorderService.grabando) {
                val s = (System.currentTimeMillis() - RecorderService.inicio) / 1000
                estado.text = String.format("Grabando…  %02d:%02d", s / 60, s % 60)
                handler.postDelayed(this, 500)
            }
        }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        estado = TextView(this).apply {
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }
        boton = Button(this).apply {
            textSize = 18f
            setOnClickListener { alternar() }
        }
        lista = ListView(this)
        lista.setOnItemClickListener { _, _, pos, _ -> reproducir(archivos[pos]) }

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
            addView(estado)
            addView(boton)
            addView(TextView(this@MainActivity).apply {
                text = "Grabaciones (toca una para escucharla)"
                setPadding(0, dp(24), 0, dp(8))
            })
            addView(
                lista,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        setContentView(raiz)
    }

    override fun onResume() {
        super.onResume()
        RecorderService.alCambiar = { runOnUiThread { refrescar() } }
        refrescar()
    }

    override fun onPause() {
        super.onPause()
        RecorderService.alCambiar = null
        handler.removeCallbacks(reloj)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
    }

    private fun carpeta() = File(getExternalFilesDir(null) ?: filesDir, "grabaciones")

    private fun refrescar() {
        archivos = (carpeta().listFiles { f -> f.name.endsWith(".m4a") } ?: emptyArray<File>())
            .sortedByDescending { it.name }
        lista.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            archivos.map { it.nameWithoutExtension.replace('_', ' ') + "  (" + it.length() / 1024 + " KB)" }
        )
        handler.removeCallbacks(reloj)
        if (RecorderService.grabando) {
            boton.text = "Detener grabación"
            handler.post(reloj)
        } else {
            boton.text = "Empezar a grabar"
            estado.text = "Listo para grabar"
        }
    }

    private fun alternar() {
        if (RecorderService.grabando) {
            startService(Intent(this, RecorderService::class.java).apply {
                action = RecorderService.ACCION_DETENER
            })
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val pedir = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) pedir.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(pedir.toTypedArray(), 1)
            return
        }
        startForegroundService(Intent(this, RecorderService::class.java).apply {
            action = RecorderService.ACCION_GRABAR
        })
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            alternar()
        }
    }

    private fun reproducir(f: File) {
        player?.release()
        player = null
        try {
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                setOnCompletionListener { it.release() }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo reproducir", Toast.LENGTH_SHORT).show()
        }
    }
}
