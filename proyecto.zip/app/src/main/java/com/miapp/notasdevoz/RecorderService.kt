package com.miapp.notasdevoz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderService : Service() {

    companion object {
        const val ACCION_GRABAR = "grabar"
        const val ACCION_DETENER = "detener"
        private const val CANAL = "grabacion"

        @Volatile var grabando = false
        @Volatile var inicio = 0L
        var alCambiar: (() -> Unit)? = null
    }

    private var recorder: MediaRecorder? = null
    private var archivo: File? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CANAL, "Grabación en curso", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACCION_GRABAR -> grabar()
            ACCION_DETENER -> detener()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun nuevoRecorder() =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun grabar() {
        if (grabando) return

        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val aviso = Notification.Builder(this, CANAL)
            .setContentTitle("Grabando…")
            .setContentText("Toca para volver a la app")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, aviso, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, aviso)
        }

        val carpeta = File(getExternalFilesDir(null) ?: filesDir, "grabaciones").apply { mkdirs() }
        val nombre = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault()).format(Date())
        val destino = File(carpeta, "$nombre.m4a")

        val r = nuevoRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(16000)
            r.setAudioEncodingBitRate(64000)
            r.setOutputFile(destino.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            archivo = destino
            inicio = System.currentTimeMillis()
            grabando = true
        } catch (e: Exception) {
            r.release()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        alCambiar?.invoke()
    }

    private fun detener() {
        recorder?.let {
            try {
                it.stop()
            } catch (e: Exception) {
                archivo?.delete() // grabación demasiado corta
            }
            it.release()
        }
        recorder = null
        archivo = null
        grabando = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        alCambiar?.invoke()
    }

    override fun onDestroy() {
        recorder?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        recorder = null
        grabando = false
        super.onDestroy()
    }
}
